package com.hms.service;

import com.hms.dao.IHospitalDAO;
import com.hms.entity.Patient;
import com.hms.exception.PatientNumberNotFoundException;

public class HospitalServiceImpl {

	private IHospitalDAO hospitalDAO;

	public Patient findPatientById(int patientId) {
		try {
			Patient patient = hospitalDAO.findPatientById(patientId);

			if (patient != null) {
				return patient;
			} else {
				throw new PatientNumberNotFoundException("Patient not found with ID: " + patientId);
			}
		} catch (PatientNumberNotFoundException e) {
			System.out.println("Patient not found: " + e.getMessage());
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

}